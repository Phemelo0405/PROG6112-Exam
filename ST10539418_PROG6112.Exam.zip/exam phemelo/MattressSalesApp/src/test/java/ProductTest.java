



public class ProductTest {

    private static int passed = 0;
    private static int failed = 0;

    public static void main(String[] args) {

        testTotalProductsSold();
        testAverageProductsSold();
        testMostPopularProduct();
        testPrintProductConstructs();
        testConstructorValidation();

        System.out.println();
        System.out.println("=================================");
        System.out.println("Passed: " + passed);
        System.out.println("Failed: " + failed);
        System.out.println("=================================");

        if (failed > 0) {
            System.exit(1);
        }
    }

    // ---------------------- TESTS ----------------------

    private static void testTotalProductsSold() {
        String[] products = { "Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket" };
        int[][] sales = {
            { 10, 20, 15 },
            { 25, 30, 20 },
            {  5, 10,  8 }
        };

        Product p = new Product(products, sales);
        assertEqualsInt("testTotalProductsSold", 143, p.GetTotalProductsSold());
    }

    private static void testAverageProductsSold() {
        String[] products = { "A", "B" };
        int[][] sales = { { 10, 20 }, { 30, 40 } };

        Product p = new Product(products, sales);
        assertEqualsDouble("testAverageProductsSold", 25.0, p.GetAverageProductsSold(), 0.0001);
    }

    private static void testMostPopularProduct() {
        String[] products = { "A", "B", "C" };
        int[][] sales = {
            { 1, 1, 1 },
            { 5, 5, 5 },
            { 2, 2, 2 }
        };

        Product p = new Product(products, sales);
        assertEqualsString("testMostPopularProduct (name)", "B", p.GetMostPopularProduct());
        assertEqualsInt("testMostPopularProduct (sales)", 15, p.GetMostPopularProductSales());
    }

    private static void testPrintProductConstructs() {
        String[] products = { "A" };
        int[][] sales = { { 5 } };

        Product p = new Product(products, sales);
        PrintProduct report = new PrintProduct(p);

        if (report != null) {
            pass("testPrintProductConstructs");
        } else {
            fail("testPrintProductConstructs", "expected non-null PrintProduct");
        }
    }

    private static void testConstructorValidation() {
        try {
            new Product(new String[] { "A" }, new int[][] { { 1 }, { 2 } });
            fail("testConstructorValidation", "expected IllegalArgumentException for mismatched rows");
        } catch (IllegalArgumentException e) {
            pass("testConstructorValidation");
        }
    }

    // ---------------------- ASSERT HELPERS ----------------------

    private static void assertEqualsInt(String name, int expected, int actual) {
        if (expected == actual) pass(name);
        else fail(name, "expected " + expected + " but was " + actual);
    }

    private static void assertEqualsDouble(String name, double expected, double actual, double delta) {
        if (Math.abs(expected - actual) <= delta) pass(name);
        else fail(name, "expected " + expected + " but was " + actual);
    }

    private static void assertEqualsString(String name, String expected, String actual) {
        if (expected == null ? actual == null : expected.equals(actual)) pass(name);
        else fail(name, "expected \"" + expected + "\" but was \"" + actual + "\"");
    }

    private static void pass(String name) {
        passed++;
        System.out.println("[PASS] " + name);
    }

    private static void fail(String name, String reason) {
        failed++;
        System.out.println("[FAIL] " + name + " -> " + reason);
    }
}

// =====================================================================
// IProducts — inlined
// =====================================================================
interface IProducts {
    int GetTotalProductsSold();
    double GetAverageProductsSold();
    String GetMostPopularProduct();
    int GetMostPopularProductSales();
}

// =====================================================================
// Product — inlined
// =====================================================================
class Product implements IProducts {

    private String[] products;
    private int[][] sales;

    public Product(String[] products, int[][] sales) {

        if (products == null || sales == null) {
            throw new IllegalArgumentException("Products and sales cannot be null.");
        }
        if (products.length != sales.length) {
            throw new IllegalArgumentException(
                    "Products and sales must have the same number of rows.");
        }
        for (int i = 0; i < sales.length; i++) {
            if (sales[i] == null) {
                throw new IllegalArgumentException("Sales row " + i + " cannot be null.");
            }
        }

        this.products = products;
        this.sales = sales;
    }

    @Override
    public int GetTotalProductsSold() {
        int total = 0;
        for (int i = 0; i < sales.length; i++)
            for (int j = 0; j < sales[i].length; j++)
                total += sales[i][j];
        return total;
    }

    @Override
    public double GetAverageProductsSold() {
        int total = GetTotalProductsSold();
        int count = 0;
        for (int i = 0; i < sales.length; i++) count += sales[i].length;
        if (count == 0) return 0;
        return (double) total / count;
    }

    @Override
    public String GetMostPopularProduct() {
        if (products.length == 0) return "No products available";

        int highestSales = -1;
        String popularProduct = "";

        for (int i = 0; i < sales.length; i++) {
            int productTotal = 0;
            for (int j = 0; j < sales[i].length; j++) productTotal += sales[i][j];
            if (productTotal > highestSales) {
                highestSales = productTotal;
                popularProduct = products[i];
            }
        }
        return popularProduct;
    }

    @Override
    public int GetMostPopularProductSales() {
        int highestSales = -1;
        for (int i = 0; i < sales.length; i++) {
            int productTotal = 0;
            for (int j = 0; j < sales[i].length; j++) productTotal += sales[i][j];
            if (productTotal > highestSales) highestSales = productTotal;
        }
        return Math.max(highestSales, 0);
    }
}

// =====================================================================
// PrintProduct — inlined
// =====================================================================
class PrintProduct {

    private Product product;

    public PrintProduct(Product product) {
        if (product == null) throw new IllegalArgumentException("Product cannot be null.");
        this.product = product;
    }

    public void PrintHeader() {
        System.out.println("PRODUCT SALES REPORT - 2026");
        System.out.println("************************************");
    }

    public void PrintTotalSales() {
        System.out.println("TOTAL PRODUCT SALES: " + product.GetTotalProductsSold());
    }

    public void PrintAverageSales() {
        System.out.printf("AVERAGE PRODUCT SALES: %.2f%n", product.GetAverageProductsSold());
    }

    public void PrintMostPopularProduct() {
        System.out.println("MOST POPULAR PRODUCT: "
                + product.GetMostPopularProduct()
                + " (" + product.GetMostPopularProductSales() + ")");
    }

    public void PrintFooter() {
        System.out.println("************************************");
    }

    public void PrintFullReport() {
        PrintHeader();
        PrintTotalSales();
        PrintAverageSales();
        PrintMostPopularProduct();
        PrintFooter();
    }
}