package com.mycompany.mattresssalesapp;

public class PrintProduct {

    private Product product;

    // Constructor
    public PrintProduct(Product product) {
        if (product == null) {
            throw new IllegalArgumentException("Product cannot be null.");
        }
        this.product = product;
    }

    // Print report header
    public void PrintHeader() {
        System.out.println("PRODUCT SALES REPORT - 2026");
        System.out.println("************************************");
    }

    // Print total sales
    public void PrintTotalSales() {
        System.out.println("TOTAL PRODUCT SALES: "
                + product.GetTotalProductsSold());
    }

    // Print average sales
    public void PrintAverageSales() {
        System.out.printf("AVERAGE PRODUCT SALES: %.2f%n",
                product.GetAverageProductsSold());
    }

    // Print most popular product
    public void PrintMostPopularProduct() {
        System.out.println("MOST POPULAR PRODUCT: "
                + product.GetMostPopularProduct()
                + " (" + product.GetMostPopularProductSales() + ")");
    }

    // Print footer
    public void PrintFooter() {
        System.out.println("************************************");
    }

    // Convenience method to print the whole report
    public void PrintFullReport() {
        PrintHeader();
        PrintTotalSales();
        PrintAverageSales();
        PrintMostPopularProduct();
        PrintFooter();
    }
}