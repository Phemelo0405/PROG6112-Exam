package com.mycompany.mattresssalesapp;

import java.util.InputMismatchException;
import java.util.Scanner;

public class MattressSalesApp {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        String[] products = {
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        };

        int months = 3;
        int[][] sales = new int[products.length][months];

        System.out.println("MATTRESS SALES SYSTEM");
        System.out.println("=====================");

        for (int i = 0; i < products.length; i++) {

            for (int j = 0; j < sales[i].length; j++) {

                boolean valid = false;

                while (!valid) {
                    System.out.print("Enter sales for month "
                            + (j + 1) + " for " + products[i] + ": ");

                    try {
                        int value = input.nextInt();

                        if (value < 0) {
                            System.out.println("Sales cannot be negative. Try again.");
                        } else {
                            sales[i][j] = value;
                            valid = true;
                        }

                    } catch (InputMismatchException e) {
                        System.out.println("Invalid input. Please enter a whole number.");
                        input.nextLine(); // clear the bad token
                    }
                }
            }

            System.out.println();
        }

        input.close();

        Product p = new Product(products, sales);

        PrintProduct report = new PrintProduct(p);

        System.out.println();
        report.PrintFullReport();
    }
}