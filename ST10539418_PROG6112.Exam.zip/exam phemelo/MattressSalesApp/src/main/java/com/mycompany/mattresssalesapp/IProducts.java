/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


package com.mycompany.mattresssalesapp;

public interface IProducts {

    int GetTotalProductsSold();

    double GetAverageProductsSold();

    String GetMostPopularProduct();

}
