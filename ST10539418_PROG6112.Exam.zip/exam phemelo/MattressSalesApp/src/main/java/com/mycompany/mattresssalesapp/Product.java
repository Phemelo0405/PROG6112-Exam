package com.mycompany.mattresssalesapp;

public class Product implements IProducts {

    private String[] products;
    private int[][] sales;

    // Constructor with validation
    public Product(String[] products, int[][] sales) {

        if (products == null || sales == null) {
            throw new IllegalArgumentException("Products and sales cannot be null.");
        }

        if (products.length != sales.length) {
            throw new IllegalArgumentException(
                    "Products and sales must have the same number of rows.");
        }

        for (int i = 0; i < sales.length; i++) {
            if (sales[i] == null) {
                throw new IllegalArgumentException(
                        "Sales row " + i + " cannot be null.");
            }
        }

        this.products = products;
        this.sales = sales;
    }

    // Calculate total products sold
    @Override
    public int GetTotalProductsSold() {

        int total = 0;

        for (int i = 0; i < sales.length; i++) {
            for (int j = 0; j < sales[i].length; j++) {
                total += sales[i][j];
            }
        }

        return total;
    }

    // Calculate average products sold
    @Override
    public double GetAverageProductsSold() {

        int total = GetTotalProductsSold();
        int count = 0;

        for (int i = 0; i < sales.length; i++) {
            count += sales[i].length;
        }

        if (count == 0) {
            return 0;
        }

        return (double) total / count;
    }

    // Find most popular product
    @Override
    public String GetMostPopularProduct() {

        if (products.length == 0) {
            return "No products available";
        }

        int highestSales = -1;
        String popularProduct = "";

        for (int i = 0; i < sales.length; i++) {

            int productTotal = 0;

            for (int j = 0; j < sales[i].length; j++) {
                productTotal += sales[i][j];
            }

            if (productTotal > highestSales) {
                highestSales = productTotal;
                popularProduct = products[i];
            }
        }

        return popularProduct;
    }

    // Get highest product sales
    public int GetMostPopularProductSales() {

        int highestSales = -1;

        for (int i = 0; i < sales.length; i++) {

            int productTotal = 0;

            for (int j = 0; j < sales[i].length; j++) {
                productTotal += sales[i][j];
            }

            if (productTotal > highestSales) {
                highestSales = productTotal;
            }
        }

        return Math.max(highestSales, 0);
    }
}