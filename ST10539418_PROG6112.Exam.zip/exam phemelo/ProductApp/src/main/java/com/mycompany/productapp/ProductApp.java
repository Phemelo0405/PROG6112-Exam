/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.productapp;



import javax.swing.*;
import java.awt.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class ProductApp extends JFrame {

    private JTextField txtCustomerName;
    private JComboBox<String> cmbProduct;
    private JTextField txtPrice;
    private JButton btnProcess;

    public ProductApp() {
        // Setup Window
        setTitle("Product App");
        setSize(450, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // 1. Create Menu Bar
        createMenuBar();

        // 2. Create Form Panel
        createFormPanel();
    }

    private void createMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        // File Menu
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);

        // Tools Menu
        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processItem = new JMenuItem("Process");
        JMenuItem clearItem = new JMenuItem("Clear");
        
        // Process menu item calls the same logic as the button
        processItem.addActionListener(e -> processData());
        
        // Clear menu item clears fields
        clearItem.addActionListener(e -> {
            txtCustomerName.setText("");
            txtPrice.setText("");
            cmbProduct.setSelectedIndex(0);
            txtCustomerName.requestFocus();
        });

        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        setJMenuBar(menuBar);
    }

    private void createFormPanel() {
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Customer Name Label & TextBox
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Customer Name:"), gbc);
        
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtCustomerName = new JTextField();
        formPanel.add(txtCustomerName, gbc);

        // Select Product Label & Combo Box
        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0;
        formPanel.add(new JLabel("Select Product:"), gbc);
        
        gbc.gridx = 1; gbc.weightx = 1.0;
        String[] products = {"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"};
        cmbProduct = new JComboBox<>(products);
        formPanel.add(cmbProduct, gbc);

        // Enter Price Label & TextBox
        gbc.gridx = 0; gbc.gridy = 2; gbc.weightx = 0;
        formPanel.add(new JLabel("Enter Price:"), gbc);
        
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtPrice = new JTextField();
        formPanel.add(txtPrice, gbc);

        // Process Button
        gbc.gridx = 0; gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        btnProcess = new JButton("PROCESS");
        btnProcess.setPreferredSize(new Dimension(200, 35));
        btnProcess.addActionListener(e -> processData());
        formPanel.add(btnProcess, gbc);

        add(formPanel, BorderLayout.CENTER);
    }

    private void processData() {
        // Validation
        String customerName = txtCustomerName.getText().trim();
        String productName = (String) cmbProduct.getSelectedItem();
        String priceStr = txtPrice.getText().trim();

        if (customerName.isEmpty() || priceStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double price;
        try {
            price = Double.parseDouble(priceStr);
            if (price < 0) throw new NumberFormatException();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid positive number for price.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Calculations
        ProductCalculations calc = new ProductCalculations(price);
        double vat = calc.GetVat();
        double commission = calc.GetCommission();
        double total = calc.GetTotal();

        // Q.2.3: Display Message
        String message = String.format(
            "Customer Name: %s\n" +
            "Product: %s\n" +
            "VAT: R %.1f\n" +
            "COMMISSION: R %.1f\n" +
            "TOTAL: R %.1f",
            customerName, productName, vat, commission, total
        );
        JOptionPane.showMessageDialog(this, message, "Message", JOptionPane.INFORMATION_MESSAGE);

        // Q.2.3: Save to data.txt
        saveToFile(customerName, productName, vat, commission, total);
    }

    private void saveToFile(String name, String product, double vat, double comm, double total) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("data.txt", true))) {
            // Appending to file in case multiple processes are done
            writer.write("DATA LOG\n");
            writer.write("****************************************\n");
            writer.write("Customer Name: " + name + "\n");
            writer.write("Product: " + product + "\n");
            writer.write(String.format("VAT: R %.1f\n", vat));
            writer.write(String.format("COMMISSION: R %.1f\n", comm));
            writer.write(String.format("TOTAL: R %.1f\n", total));
            writer.write("****************************************\n\n");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving to data.txt: " + e.getMessage(), "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        // Run the GUI on the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            new ProductApp().setVisible(true);
        });
    }
}